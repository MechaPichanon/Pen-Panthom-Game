package main;

import object.*;

public class AssetSetter {
    GamePanel gp;

    public AssetSetter(GamePanel gp){
        this.gp = gp;
    }

    public void setObject(){
        gp.obj[0] = new OBJ_spirit1();
        gp.obj[0].worldX = 1 * gp.titlesize;
        gp.obj[0].worldY = 101 * gp.titlesize;

        gp.obj[1] = new OBJ_plate5();
        gp.obj[1].worldX = 3 * gp.titlesize;
        gp.obj[1].worldY = 84 * gp.titlesize;

        gp.obj[2] = new OBJ_plate1();
        gp.obj[2].worldX = 3 * gp.titlesize;
        gp.obj[2].worldY = 96 * gp.titlesize;

        gp.obj[3] = new OBJ_plate2();
        gp.obj[3].worldX = 6 * gp.titlesize;
        gp.obj[3].worldY = 96 * gp.titlesize;

        gp.obj[4] = new OBJ_plate3();
        gp.obj[4].worldX = 9 * gp.titlesize;
        gp.obj[4].worldY = 96 * gp.titlesize;

        gp.obj[5] = new OBJ_plate4();
        gp.obj[5].worldX = 12 * gp.titlesize;
        gp.obj[5].worldY = 96 * gp.titlesize;

        gp.obj[6] = new OBJ_shoes();
        gp.obj[6].worldX = 8 * gp.titlesize;
        gp.obj[6].worldY = 77 * gp.titlesize;

        gp.obj[7] = new OBJ_plate6();
        gp.obj[7].worldX = 6 * gp.titlesize;
        gp.obj[7].worldY = 84 * gp.titlesize;

        gp.obj[8] = new OBJ_plate7();
        gp.obj[8].worldX = 9 * gp.titlesize;
        gp.obj[8].worldY = 84 * gp.titlesize;

        gp.obj[9] = new OBJ_plate8();
        gp.obj[9].worldX = 12 * gp.titlesize;
        gp.obj[9].worldY = 84 * gp.titlesize;

        gp.obj[10] = new OBJ_plate9();
        gp.obj[10].worldX = 3 * gp.titlesize;
        gp.obj[10].worldY = 72 * gp.titlesize;

        gp.obj[11] = new OBJ_plate10();
        gp.obj[11].worldX = 6 * gp.titlesize;
        gp.obj[11].worldY = 72 * gp.titlesize;

        gp.obj[12] = new OBJ_plate11();
        gp.obj[12].worldX = 9 * gp.titlesize;
        gp.obj[12].worldY = 72 * gp.titlesize;

        gp.obj[13] = new OBJ_plate12();
        gp.obj[13].worldX = 12 * gp.titlesize;
        gp.obj[13].worldY = 72 * gp.titlesize;

        gp.obj[14] = new OBJ_plate13();
        gp.obj[14].worldX = 3 * gp.titlesize;
        gp.obj[14].worldY = 60 * gp.titlesize;

        gp.obj[15] = new OBJ_plate14();
        gp.obj[15].worldX = 6 * gp.titlesize;
        gp.obj[15].worldY = 60 * gp.titlesize;

        gp.obj[16] = new OBJ_plate15();
        gp.obj[16].worldX = 9 * gp.titlesize;
        gp.obj[16].worldY = 60 * gp.titlesize;

        gp.obj[17] = new OBJ_plate16();
        gp.obj[17].worldX = 12 * gp.titlesize;
        gp.obj[17].worldY = 60 * gp.titlesize;

        gp.obj[18] = new OBJ_plate17();
        gp.obj[18].worldX = 3 * gp.titlesize;
        gp.obj[18].worldY = 48 * gp.titlesize;

        gp.obj[19] = new OBJ_plate18();
        gp.obj[19].worldX = 6 * gp.titlesize;
        gp.obj[19].worldY = 48 * gp.titlesize;

        gp.obj[20] = new OBJ_plate19();
        gp.obj[20].worldX = 9 * gp.titlesize;
        gp.obj[20].worldY = 48 * gp.titlesize;

        gp.obj[21] = new OBJ_plate20();
        gp.obj[21].worldX = 12 * gp.titlesize;
        gp.obj[21].worldY = 48 * gp.titlesize;

        gp.obj[22] = new OBJ_plate21();
        gp.obj[22].worldX = 3 * gp.titlesize;
        gp.obj[22].worldY = 36 * gp.titlesize;

        gp.obj[23] = new OBJ_plate22();
        gp.obj[23].worldX = 6 * gp.titlesize;
        gp.obj[23].worldY = 36 * gp.titlesize;

        gp.obj[24] = new OBJ_plate23();
        gp.obj[24].worldX = 9 * gp.titlesize;
        gp.obj[24].worldY = 36 * gp.titlesize;

        gp.obj[25] = new OBJ_plate24();
        gp.obj[25].worldX = 12 * gp.titlesize;
        gp.obj[25].worldY = 36 * gp.titlesize;

        gp.obj[26] = new OBJ_plate25();
        gp.obj[26].worldX = 3 * gp.titlesize;
        gp.obj[26].worldY = 24 * gp.titlesize;

        gp.obj[27] = new OBJ_plate26();
        gp.obj[27].worldX = 6 * gp.titlesize;
        gp.obj[27].worldY = 24 * gp.titlesize;

        gp.obj[28] = new OBJ_plate27();
        gp.obj[28].worldX = 9 * gp.titlesize;
        gp.obj[28].worldY = 24 * gp.titlesize;

        gp.obj[29] = new OBJ_plate28();
        gp.obj[29].worldX = 12 * gp.titlesize;
        gp.obj[29].worldY = 24 * gp.titlesize;

        gp.obj[30] = new OBJ_plate29();
        gp.obj[30].worldX = 3 * gp.titlesize;
        gp.obj[30].worldY = 12 * gp.titlesize;


        gp.obj[31] = new OBJ_plate30();
        gp.obj[31].worldX = 6 * gp.titlesize;
        gp.obj[31].worldY = 12 * gp.titlesize;


        gp.obj[32] = new OBJ_plate31();
        gp.obj[32].worldX = 9 * gp.titlesize;
        gp.obj[32].worldY = 12 * gp.titlesize;


        gp.obj[33] = new OBJ_plate32();
        gp.obj[33].worldX = 12 * gp.titlesize;
        gp.obj[33].worldY = 12 * gp.titlesize;

        gp.obj[34] = new OBJ_spirit2();
        gp.obj[34].worldX = 8 * gp.titlesize;
        gp.obj[34].worldY = 87 * gp.titlesize;

        gp.obj[35] = new OBJ_spirit3();
        gp.obj[35].worldX = 1 * gp.titlesize;
        gp.obj[35].worldY = 77 * gp.titlesize;

        gp.obj[36] = new OBJ_spirit4();
        gp.obj[36].worldX = 14 * gp.titlesize;
        gp.obj[36].worldY = 67 * gp.titlesize;

        gp.obj[37] = new OBJ_spirit5();
        gp.obj[37].worldX = 7 * gp.titlesize;
        gp.obj[37].worldY = 53 * gp.titlesize;

        gp.obj[38] = new OBJ_spirit6();
        gp.obj[38].worldX = 4 * gp.titlesize;
        gp.obj[38].worldY = 41 * gp.titlesize;

        gp.obj[39] = new OBJ_spirit7();
        gp.obj[39].worldX = 14 * gp.titlesize;
        gp.obj[39].worldY = 27 * gp.titlesize;

        gp.obj[40] = new OBJ_spirit8();
        gp.obj[40].worldX = 1 * gp.titlesize;
        gp.obj[40].worldY = 13 * gp.titlesize;

        gp.obj[41] = new OBJ_Life();
        gp.obj[41].worldX = 11 * gp.titlesize;
        gp.obj[41].worldY = 63 * gp.titlesize;

        gp.obj[42] = new OBJ_Life();
        gp.obj[42].worldX = 4 * gp.titlesize;
        gp.obj[42].worldY = 30 * gp.titlesize;

        gp.obj[43] = new OBJ_yurei1();
        gp.obj[43].worldX = 7 * gp.titlesize;
        gp.obj[43].worldY = 3 * gp.titlesize;

        gp.obj[44] = new OBJ_yurei2();
        gp.obj[44].worldX = 7 * gp.titlesize;
        gp.obj[44].worldY = 4 * gp.titlesize;

        gp.obj[45] = new OBJ_spike();
        gp.obj[45].worldX = 2 * gp.titlesize;
        gp.obj[45].worldY = 14 * gp.titlesize;

        gp.obj[46] = new OBJ_spike();
        gp.obj[46].worldX = 11 * gp.titlesize;
        gp.obj[46].worldY = 88 * gp.titlesize;

        gp.obj[47] = new OBJ_spike();
        gp.obj[47].worldX = 12 * gp.titlesize;
        gp.obj[47].worldY = 88 * gp.titlesize;

        gp.obj[48] = new OBJ_spike();
        gp.obj[48].worldX = 13 * gp.titlesize;
        gp.obj[48].worldY = 88 * gp.titlesize;

        gp.obj[49] = new OBJ_spike();
        gp.obj[49].worldX = 14 * gp.titlesize;
        gp.obj[49].worldY = 88 * gp.titlesize;

        gp.obj[50] = new OBJ_spike();
        gp.obj[50].worldX = 6 * gp.titlesize;
        gp.obj[50].worldY = 52 * gp.titlesize;

        gp.obj[51] = new OBJ_spike();
        gp.obj[51].worldX = 8 * gp.titlesize;
        gp.obj[51].worldY = 52 * gp.titlesize;

        gp.obj[52] = new OBJ_spike();
        gp.obj[52].worldX = 7 * gp.titlesize;
        gp.obj[52].worldY = 54 * gp.titlesize;

        gp.obj[53] = new OBJ_spike();
        gp.obj[53].worldX = 1 * gp.titlesize;
        gp.obj[53].worldY = 40 * gp.titlesize;

        gp.obj[54] = new OBJ_spike();
        gp.obj[54].worldX = 11 * gp.titlesize;
        gp.obj[54].worldY = 27 * gp.titlesize;

        gp.obj[55] = new OBJ_spike();
        gp.obj[55].worldX = 3 * gp.titlesize;
        gp.obj[55].worldY = 27 * gp.titlesize;

        gp.obj[56] = new OBJ_spike();
        gp.obj[56].worldX = 3 * gp.titlesize;
        gp.obj[56].worldY = 16 * gp.titlesize;

        gp.obj[57] = new OBJ_spike();
        gp.obj[57].worldX = 5 * gp.titlesize;
        gp.obj[57].worldY = 18 * gp.titlesize;

        gp.obj[58] = new OBJ_spike();
        gp.obj[58].worldX = 7 * gp.titlesize;
        gp.obj[58].worldY = 20 * gp.titlesize;

    }
}
