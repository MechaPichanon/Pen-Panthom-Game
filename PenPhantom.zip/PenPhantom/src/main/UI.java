package main;

import object.*;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;

public class UI {
    GamePanel gp;
    Font arial_40, arial_80B;
    BufferedImage LifeImage,spi1Im,spi2Im,spi3Im,spi4Im,spi5Im,spi7Im,spi8Im,spi6Im,ShoesIm;
    public boolean gameFinished = false;
    public boolean gameOver = false;
    public Rectangle restartButtonBounds = new Rectangle(280,360 , 200, 50);
    public int commandNum = 0;

    public double playTime;
    DecimalFormat dFormat = new DecimalFormat("#0.00");
    public UI(GamePanel gp){
       this.gp = gp;

       arial_40 = new Font("Arial",Font.PLAIN,40);
        arial_80B = new Font("Arial",Font.BOLD,80);
        OBJ_Life life = new OBJ_Life();
        OBJ_spirit1 spirit1 = new OBJ_spirit1();
        OBJ_spirit2 spirit2 = new OBJ_spirit2();
        OBJ_spirit3 spirit3 = new OBJ_spirit3();
        OBJ_spirit4 spirit4 = new OBJ_spirit4();
        OBJ_spirit5 spirit5 = new OBJ_spirit5();
        OBJ_spirit6 spirit6 = new OBJ_spirit6();
        OBJ_spirit7 spirit7 = new OBJ_spirit7();
        OBJ_spirit8 spirit8 = new OBJ_spirit8();
        OBJ_shoes shoess = new OBJ_shoes();
        LifeImage = life.image;
        spi1Im = spirit1.image;
        spi2Im = spirit2.image;
        spi3Im = spirit3.image;
        spi4Im = spirit4.image;
        spi5Im = spirit5.image;
        spi6Im = spirit6.image;
        spi7Im = spirit7.image;
        spi8Im = spirit8.image;
        ShoesIm = shoess.image;

        if(gp.player.life == 0){
            gameOver = true;
        }

    }
    public void mouseClicked(MouseEvent e){
        if(gameOver || gameFinished){
            if(restartButtonBounds.contains(e.getPoint())){
                restartGame();
            }
        }
    }

    private void restartGame() {

        gameOver = false;
        gameFinished = false;
        playTime = 0;
        gp.player.setDefaultValues();
        gp.player.life = 3;

        gp.aSetter.setObject();
        gp.startGameThread();
    }

    public void draw(Graphics2D g2){
        if(gameFinished == true){
            String text;
            int textlenght;
            int x;
            int y;

            g2.setColor(new Color(0,0,0,150));
            g2.fillRect(0,0,gp.screemWidth,gp.screenHeight);

            g2.setFont(arial_40);
            g2.setColor(Color.white);

            text = "You've captured all the spirits in this floor";
            textlenght = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
            x = gp.screemWidth/2 - textlenght/2;
            y = gp.screenHeight/2 - (gp.titlesize*3);
            g2.drawString(text,x,y+90);

            text = "Your Time: "+dFormat.format(playTime);
            textlenght = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
            x = gp.screemWidth/2 - textlenght/2;
            y = gp.screenHeight/2 + (gp.titlesize*4);
            g2.drawString(text,x,y-150);

            g2.setFont(arial_80B);
            g2.setColor(Color.white);

            text = "You Win!!";
            textlenght = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
            g2.drawString(text,200,150);

            g2.drawRect(restartButtonBounds.x, restartButtonBounds.y, restartButtonBounds.width, restartButtonBounds.height);
            g2.setFont(g2.getFont().deriveFont(50f));
            text = "Retry";
            g2.drawString(text,320,400);

            gp.gameThread = null;

        }
        else if(gameOver == true){
            int textlenght;
            g2.setColor(new Color(0,0,0,150));
            g2.fillRect(0,0,gp.screemWidth,gp.screenHeight);

            int x;
            int y;
            String text;
            g2.setFont(g2.getFont().deriveFont(Font.BOLD,110f));

            text = "Game Over";
            g2.setColor(Color.WHITE);
            g2.drawString(text,90,150);

            g2.setFont(arial_40);
            g2.setColor(Color.white);
            text = "Your Time: "+dFormat.format(playTime);
            textlenght = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
            x = gp.screemWidth/2 - textlenght/2;
            y = gp.screenHeight/2 + (gp.titlesize*4);
            g2.drawString(text,x,y-150);

            g2.drawRect(restartButtonBounds.x, restartButtonBounds.y, restartButtonBounds.width, restartButtonBounds.height);
            g2.setFont(g2.getFont().deriveFont(50f));
            text = "Retry";
            g2.drawString(text,320,400);



            gp.gameThread = null;
        }
        else {
            g2.setFont(arial_40);
            g2.setColor(Color.white);
            g2.drawImage(LifeImage,gp.titlesize/2,gp.titlesize/2,gp.titlesize,gp.titlesize,null);
            g2.drawString("x "+gp.player.life,75,63);

            playTime += (double) 1/60;
            g2.drawString("Time :"+dFormat.format(playTime),gp.titlesize*11,65);

            if(gp.player.spi1 >0) {
                g2.drawImage(spi1Im, 50, 100, gp.titlesize, gp.titlesize, null);
            }
            if(gp.player.spi2 >0){
                g2.drawImage(spi2Im,50,100,gp.titlesize,gp.titlesize,null);
            }
            if(gp.player.spi3 >0){
                g2.drawImage(spi3Im,50,100,gp.titlesize,gp.titlesize,null);
            }
            if(gp.player.spi4 >0){
                g2.drawImage(spi4Im,50,100,gp.titlesize,gp.titlesize,null);
            }
            if(gp.player.spi5 >0){
                g2.drawImage(spi5Im,50,100,gp.titlesize,gp.titlesize,null);
            }
            if(gp.player.spi6 >0){
                g2.drawImage(spi6Im,50,100,gp.titlesize,gp.titlesize,null);
            }
            if(gp.player.spi7 >0){
                g2.drawImage(spi7Im,50,100,gp.titlesize,gp.titlesize,null);
            }
            if(gp.player.spi8 >0){
                g2.drawImage(spi8Im,50,100,gp.titlesize,gp.titlesize,null);
            }
            if(gp.player.speedCheck >0){
                g2.drawImage(ShoesIm,50,150,gp.titlesize,gp.titlesize,null);
            }
        }

    }
}
