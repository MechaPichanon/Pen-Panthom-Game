package main;

import entity.Player;
import object.SuperObject;
import tile.TileManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GamePanel extends JPanel implements Runnable{
    //screen setting
    final int originalTitleSize = 16; //16x16
    final int scale = 3;
    public final int titlesize = originalTitleSize * scale; //48x48
    public final int maxScreenCol = 16;
    public final int maxScreemRow = 12;
    public final int screemWidth = titlesize * maxScreenCol;
    public final int screenHeight = titlesize * maxScreemRow;
    public final int maxWorldCol = 16;
    public final int maxWorldRow = 108;
    public final int worldWidth = titlesize * maxWorldCol;
    public final int worldHeight = titlesize * maxWorldRow;
    //Fps set
    int FPS = 60;
    background Backg = new background(this);

    TileManager tileM = new TileManager(this);
    KeyHandler keyH = new KeyHandler();
    Thread gameThread;
    public CollisionChecker cChecker = new CollisionChecker(this);
    public Player player = new Player(this,keyH);
    public SuperObject obj[] = new SuperObject[70];
    public AssetSetter aSetter = new AssetSetter(this);
    public UI ui = new UI(this);
    //setplayer positions

    public  GamePanel(){
        this.setPreferredSize(new Dimension(screemWidth,screenHeight));
        this.setBackground(Color.GRAY);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                ui.mouseClicked(e);
            }
        });

        ui = new UI(this);
    }
    public void setupGame(){
        aSetter.setObject();
    }

    public void restartGame(){
        this.player.life = 3;
        this.player.speed = 4;
        this.ui.playTime = 0;
        aSetter.setObject();

        repaint();
    }
    public void startGameThread(){
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run(){
        double drawInterval = 1000000000/FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;

        while (gameThread != null){
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime)/drawInterval;
            timer += (currentTime-lastTime);
            lastTime = currentTime;
            if(delta >= 1){
                update();
                repaint();
                delta--;
                drawCount++;
            }
            if(timer >= 1000000000){
                //System.out.println("FPS:"+drawCount);
                drawCount = 0;
                timer = 0;
            }

        }
    }
    public void update(){

        player.update();
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D)g;

        Backg.draw(g2);

        tileM.draw(g2);

        for(int i = 0;i< obj.length;i++){
            if(obj[i] != null){
                obj[i].draw(g2,this);
            }
        }

        player.draw(g2);

        ui.draw(g2);

        g2.dispose();
    }
}
