package main;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class background {
    public BufferedImage bg1;
    GamePanel gp;

    public background(GamePanel gp) {
        this.gp = gp;
        getbg();
    }
    public void getbg(){
        try{
            bg1 = ImageIO.read(getClass().getResourceAsStream("/Background/bgs.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw(Graphics2D g2){
        BufferedImage image = null;
        image = bg1;
        g2.drawImage(image,0,0,1000,1000,null);

    }

}
