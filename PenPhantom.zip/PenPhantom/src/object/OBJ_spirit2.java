package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_spirit2 extends SuperObject{
    public OBJ_spirit2(){
        name = "spirit2";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ku_spirit.png"));
        }catch (IOException e){
            e.printStackTrace();
        }


    }
}
