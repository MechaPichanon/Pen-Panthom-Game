package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_yurei2 extends SuperObject{
    public OBJ_yurei2(){
        name = "yurei2";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/Yurei2.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
