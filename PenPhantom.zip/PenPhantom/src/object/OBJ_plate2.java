package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate2 extends SuperObject{
    public OBJ_plate2(){
        name = "plate2";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/I.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
