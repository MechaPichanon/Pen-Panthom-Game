package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate31 extends SuperObject{
    public OBJ_plate31(){
        name = "plate31";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ro.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
