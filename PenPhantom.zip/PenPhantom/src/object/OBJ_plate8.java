package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate8 extends SuperObject{
    public OBJ_plate8(){
        name = "plate8";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/Ku.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
