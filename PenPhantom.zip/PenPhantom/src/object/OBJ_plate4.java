package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate4 extends SuperObject{
    public OBJ_plate4(){
        name = "plate4";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/E.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
