package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate7 extends SuperObject{
    public OBJ_plate7(){
        name = "plate7";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/Ko.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
