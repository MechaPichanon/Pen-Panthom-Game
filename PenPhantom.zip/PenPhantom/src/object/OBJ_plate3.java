package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate3 extends SuperObject{
    public OBJ_plate3(){
        name = "plate3";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/U.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
