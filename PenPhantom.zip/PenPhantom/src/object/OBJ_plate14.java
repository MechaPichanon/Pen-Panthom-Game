package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate14 extends SuperObject{
    public OBJ_plate14(){
        name = "plate14";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/te.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
