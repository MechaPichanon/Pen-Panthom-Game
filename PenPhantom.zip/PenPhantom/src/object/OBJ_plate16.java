package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate16 extends SuperObject{
    public OBJ_plate16(){
        name = "plate16";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/tsu.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
