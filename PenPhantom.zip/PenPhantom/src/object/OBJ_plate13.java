package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate13 extends SuperObject{
    public OBJ_plate13(){
        name = "plate13";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ta.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
