package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate27 extends SuperObject{
    public OBJ_plate27(){
        name = "plate27";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/mo.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
