package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_spirit8 extends SuperObject{
    public OBJ_spirit8(){
        name = "spirit8";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/re_spirit.png"));
        }catch (IOException e){
            e.printStackTrace();
        }


    }
}
