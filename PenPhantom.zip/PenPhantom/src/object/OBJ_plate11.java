package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate11 extends SuperObject{
    public OBJ_plate11(){
        name = "plate11";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/so.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
