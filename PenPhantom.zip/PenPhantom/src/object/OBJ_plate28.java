package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate28 extends SuperObject{
    public OBJ_plate28(){
        name = "plate28";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/mu.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
