package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_spirit7 extends SuperObject{
    public OBJ_spirit7(){
        name = "spirit7";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/mi_spirit.png"));
        }catch (IOException e){
            e.printStackTrace();
        }


    }
}
