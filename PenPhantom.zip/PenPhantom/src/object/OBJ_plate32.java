package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate32 extends SuperObject{
    public OBJ_plate32(){
        name = "plate32";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ru.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
