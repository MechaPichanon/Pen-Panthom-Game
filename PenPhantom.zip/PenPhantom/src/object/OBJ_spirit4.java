package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_spirit4 extends SuperObject{
    public OBJ_spirit4(){
        name = "spirit4";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/te_spirit.png"));
        }catch (IOException e){
            e.printStackTrace();
        }


    }
}
