package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_spirit1 extends SuperObject{
    public OBJ_spirit1(){
        name = "spirit1";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/A_spirit.png"));
        }catch (IOException e){
            e.printStackTrace();
        }


    }
}
