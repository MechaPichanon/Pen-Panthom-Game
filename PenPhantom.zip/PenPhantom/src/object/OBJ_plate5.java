package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate5 extends SuperObject{
    public OBJ_plate5(){
        name = "plate5";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/Ka.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
