package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate17 extends SuperObject{
    public OBJ_plate17(){
        name = "plate17";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/na.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
