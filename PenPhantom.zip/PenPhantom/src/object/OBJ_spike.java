package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_spike extends SuperObject{
    public OBJ_spike(){
        name = "spike";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/spike.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
