package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate6 extends SuperObject{
    public OBJ_plate6(){
        name = "plate6";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/Ki.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
