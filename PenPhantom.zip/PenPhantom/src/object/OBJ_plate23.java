package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate23 extends SuperObject{
    public OBJ_plate23(){
        name = "plate23";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ho.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
