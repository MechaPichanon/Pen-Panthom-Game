package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate21 extends SuperObject{
    public OBJ_plate21(){
        name = "plate21";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/he.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
