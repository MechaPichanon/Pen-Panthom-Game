package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate30 extends SuperObject{
    public OBJ_plate30(){
        name = "plate30";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ri.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
