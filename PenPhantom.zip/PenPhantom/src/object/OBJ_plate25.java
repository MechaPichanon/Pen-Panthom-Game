package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate25 extends SuperObject{
    public OBJ_plate25(){
        name = "plate25";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ma.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
