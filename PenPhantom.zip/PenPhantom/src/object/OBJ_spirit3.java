package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_spirit3 extends SuperObject{
    public OBJ_spirit3(){
        name = "spirit3";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/so_spirit.png"));
        }catch (IOException e){
            e.printStackTrace();
        }


    }
}
