package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate19 extends SuperObject{
    public OBJ_plate19(){
        name = "plate19";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ni.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
