package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate18 extends SuperObject{
    public OBJ_plate18(){
        name = "plate18";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ne.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
