package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate15 extends SuperObject{
    public OBJ_plate15(){
        name = "plate15";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/to.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
