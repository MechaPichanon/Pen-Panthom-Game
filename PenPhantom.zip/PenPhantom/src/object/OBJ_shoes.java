package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_shoes extends SuperObject{
    public OBJ_shoes(){
        name = "shoes";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/shoes.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
