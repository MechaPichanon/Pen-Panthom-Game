package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate29 extends SuperObject{
    public OBJ_plate29(){
        name = "plate29";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/re.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
