package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_spirit6 extends SuperObject{
    public OBJ_spirit6(){
        name = "spirit6";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/ho_spirit.png"));
        }catch (IOException e){
            e.printStackTrace();
        }


    }
}
