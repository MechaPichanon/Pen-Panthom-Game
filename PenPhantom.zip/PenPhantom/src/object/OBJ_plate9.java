package object;

import javax.imageio.ImageIO;
import java.io.IOException;

public class OBJ_plate9 extends SuperObject{
    public OBJ_plate9(){
        name = "plate9";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/objects/se.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
        collision = true;
    }
}
