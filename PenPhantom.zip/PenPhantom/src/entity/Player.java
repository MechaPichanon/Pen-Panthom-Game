package entity;

import main.GamePanel;
import main.KeyHandler;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Player extends Entity{
    GamePanel gp;
    KeyHandler keyH;
    public final int screenX;
    public final int screenY;
    public int hasKey =0;
    public int life = 3;
    public  Player(GamePanel gp,KeyHandler keyH){
        this.gp = gp;
        this.keyH = keyH;

        screenX = gp.screemWidth/2 - (gp.titlesize/2);
        screenY = gp.screenHeight/2 - (gp.titlesize/2);

        solidArea = new Rectangle();
        solidArea.x = 8;
        solidArea.y = 16;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        solidArea.width = 32;
        solidArea.height = 32;

        setDefaultValues();
        getPlayerImage();
    }
    public void setDefaultValues(){
        worldX = gp.titlesize * 7;
        worldY = gp.titlesize * 105;
        speed = 4;
        direction = "right";
    }
    public void getPlayerImage(){
        try {
            up1 = ImageIO.read(getClass().getResourceAsStream("/player/Hiro_up1.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/player/Hiro_up2.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/player/Hiro_down1.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/player/Hiro_down2.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/player/Hiro_left1.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/player/Hiro_left2.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/player/Hiro_right1.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/player/Hiro_right2.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void update(){

        if(keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed == true || keyH.rightPressed == true){
            if(keyH.upPressed == true){
                direction = "up";

            }
            else if (keyH.downPressed == true) {
                direction = "down";

            }
            else if (keyH.leftPressed == true) {
                direction = "left";

            }
            else if (keyH.rightPressed == true) {
                direction = "right";

            }
            //check tile
            collisionOn = false;
            gp.cChecker.checkTile(this);

            int objIndex = gp.cChecker.checkObject(this,true);
            pickUpObject(objIndex);
            //if colli false player move
            if(collisionOn == false){
                switch (direction){
                    case "up":
                        worldY -= speed;
                        break;
                    case "down":
                        worldY += speed;
                        break;
                    case "left":
                        worldX -= speed;
                        break;
                    case "right":
                        worldX += speed;
                        break;
                }
            }
            spriteCounter++;
            if(spriteCounter > 13){
                if(spriteNum == 1){
                    spriteNum = 2;
                }
                else if(spriteNum == 2){
                    spriteNum = 1;
                }
                spriteCounter = 0;
            }
        }

    }
    public int spi1=0;
    public int spi2=0;
    public int spi3=0;
    public int spi4=0;
    public int spi5=0;
    public int spi6=0;
    public int spi7=0;
    public int spi8=0;
    public int speedCheck = 0;
    public void pickUpObject(int i){
        if(i != 999){
            String objectName = gp.obj[i].name;

            switch (objectName){
                case "spirit1":
                    hasKey++;
                    spi1++;
                    gp.obj[i] = null;
                    break;
                case "plate1":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi1--;
                    }
                    break;
                case "spirit2":
                    hasKey++;
                    spi2++;
                    gp.obj[i] = null;
                    break;
                case "plate8":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi2--;
                    }
                    break;
                case "spirit3":
                    hasKey++;
                    spi3++;
                    gp.obj[i] = null;
                    break;
                case "plate11":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi3--;
                    }
                    break;
                case "spirit4":
                    hasKey++;
                    spi4++;
                    gp.obj[i] = null;
                    break;
                case "plate14":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi4--;
                    }
                    break;
                case "spirit5":
                    hasKey++;
                    spi5++;
                    gp.obj[i] = null;
                    break;
                case "plate17":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi5--;
                    }
                    break;
                case "spirit6":
                    hasKey++;
                    spi6++;
                    gp.obj[i] = null;
                    break;
                case "plate23":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi6--;
                    }
                    break;
                case "spirit7":
                    hasKey++;
                    spi7++;
                    gp.obj[i] = null;
                    break;
                case "plate26":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi7--;
                    }
                    break;
                case "spirit8":
                    hasKey++;
                    spi8++;
                    gp.obj[i] = null;
                    break;
                case "plate29":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi8--;
                    }
                    break;
                case "shoes":
                    speed += 1;
                    speedCheck += 1;
                    gp.obj[i] = null;
                    break;
                case "plate2":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi1--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate3":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi1--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate4":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi1--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate5":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi2--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate6":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi2--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate7":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi2--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate9":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi3--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate10":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi3--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate12":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi3--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate13":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi4--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate15":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi4--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate16":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi4--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate18":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi5--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate19":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi5--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate20":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi5--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate21":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi6--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate22":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi6--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate24":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi6--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate25":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi7--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate27":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi7--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate28":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi7--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate30":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi8--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate31":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi8--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "plate32":
                    if(hasKey > 0){
                        gp.obj[i] = null;
                        hasKey--;
                        spi8--;
                        life--;
                        gp.ui.playTime += 10;
                    }
                    break;
                case "Life":
                    life++;
                    gp.obj[i] = null;
                    break;
                case "yurei1":
                    gp.ui.gameFinished = true;
                    break;
                case "yurei2":
                    gp.ui.gameFinished = true;
                    break;
                case "spike":
                    gp.ui.playTime += 0.1;
                    break;
            }
            if(life == 0){
                gp.ui.gameOver = true;
            }

        }
    }
    public void draw(Graphics2D g2){
        //g2.setColor(Color.white);

        //g2.fillRect(x,y,gp.titlesize,gp.titlesize);
        BufferedImage image = null;
        switch(direction){
            case "up":
                if(spriteNum == 1){
                    image = up1;
                }
                if(spriteNum == 2){
                    image = up2;
                }
                break;
            case "down":
                if(spriteNum == 1){
                    image = down1;
                }
                if(spriteNum == 2){
                    image = down2;
                }
                break;
            case "left":
                if(spriteNum == 1){
                    image = left1;
                }
                if(spriteNum == 2){
                    image = left2;
                }
                break;
            case "right":
                if(spriteNum == 1){
                    image = right1;
                }
                if(spriteNum == 2){
                    image = right2;
                }
                break;

        }
        g2.drawImage(image,screenX,screenY,gp.titlesize+20,gp.titlesize+20,null);

    }

}
